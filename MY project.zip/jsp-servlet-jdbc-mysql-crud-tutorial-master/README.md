# jsp-servlet-jdbc-mysql-crud-tutorial
JSP Servlet JDBC MySQL CRUD Example Tutorial 

https://www.javaguides.net/2019/03/jsp-servlet-jdbc-mysql-crud-example-tutorial.html
